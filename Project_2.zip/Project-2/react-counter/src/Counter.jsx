import { useState } from "react";
import "./Counter.css";

function Counter() {
    const [count, setCount] = useState(0);

    const increase = () => {
        setCount(prev => prev + 1);
    };

    const decrease = () => {
        setCount(prev => prev - 1);
    };

    const reset = () => {
        setCount(0);
    };

    return (
        <div className="page-center">
            <div className="counter-box">
                <h2 className="title">React Counter</h2>

                <div className="count-display">{count}</div>

                <div className="btn-group">
                    <button className="btn inc" onClick={increase}>+</button>
                    <button className="btn dec" onClick={decrease}>-</button>
                    <button className="btn reset" onClick={reset}>Reset</button>
                </div>
            </div>
        </div>
    );
}

export default Counter;
